//
//  FD.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct FDColor: Identifiable {
    let id = UUID()
    let FDimageName: String
    let FDtitle: String
    let FDdescription: String
    let FDRGBCode1: String
    let FDRGBCode2: String
    let FDRGBCode3: String
    let FDRGBCode4: String
    let FDRGBCode5: String
}

struct FDColorList {
    static let FDmainColor = [
        FDColor(FDimageName: "hotpink",
        FDtitle: "HotPink color and others",
        FDdescription: ".",
        FDRGBCode1: "#D92365" ,
        FDRGBCode2: "#B0A4BF" ,
        FDRGBCode3: "#F2C029" ,
        FDRGBCode4: "#D9910D" ,
        FDRGBCode5: "#A65005" ),
        
        FDColor(FDimageName: "taffypink",
        FDtitle: "TaffyPink color and others",
        FDdescription: ".",
        FDRGBCode1: "#D96C9F" ,
        FDRGBCode2: "#F2ACCD" ,
        FDRGBCode3: "#F2EBEE" ,
        FDRGBCode4: "#778C2B" ,
        FDRGBCode5: "#BBBF45" ),
        
        FDColor(FDimageName: "oldnavy",
        FDtitle: "OldNavy color and others",
        FDdescription: ".",
        FDRGBCode1: "#363E59" ,
        FDRGBCode2: "#282E40" ,
        FDRGBCode3: "#F2F2F2" ,
        FDRGBCode4: "#A69485" ,
        FDRGBCode5: "#735340" ),
        
        FDColor(FDimageName: "blackred",
        FDtitle: "BlackRed color and others",
        FDdescription: ".",
        FDRGBCode1: "#C81717" ,
        FDRGBCode2: "#000000" ,
        FDRGBCode3: "#BF8969" ,
        FDRGBCode4: "231D1D" ,
        FDRGBCode5: "#FEFEFE" ),
        
        FDColor(FDimageName: "darkbrown",
        FDtitle: "DarkBrown color and others",
        FDdescription: ".",
        FDRGBCode1: "#402116" ,
        FDRGBCode2: "#8C543F" ,
        FDRGBCode3: "#BF846F" ,
        FDRGBCode4: "D9AB9A" ,
        FDRGBCode5: "#C25555" ),
        
        FDColor(FDimageName: "lilac",
        FDtitle: "Lilac color and others",
        FDdescription: ".",
        FDRGBCode1: "#F2BDE9" ,
        FDRGBCode2: "#8C4F88" ,
        FDRGBCode3: "#253759" ,
        FDRGBCode4: "#011126" ,
        FDRGBCode5: "#D9D8D7" ),
    ]
}
