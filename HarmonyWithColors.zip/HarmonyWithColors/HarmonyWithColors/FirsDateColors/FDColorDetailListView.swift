//
//  FDColorDetailListView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct FDColorDetailView: View {
    var FDcolor: FDColor
    
    var body: some View {
        VStack(spacing:20) {
            Spacer()
            Text(FDcolor.FDtitle)
                .font(.title2)
                .fontWeight(.semibold)
                .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Image(FDcolor.FDimageName)
                .resizable()
                .scaledToFit()
                .frame(height: 150)
                .cornerRadius(12)
      
                    HStack(spacing: 35) {
//                    Text(fcolor.fimageName)
                        Text("( from left to right )")
                            .font(.footnote)
                            .foregroundColor(.secondary)
               
                    }
            
                VStack(spacing:20) {
                    HStack(spacing: 35) {
                 
// Text(color.imageName)
                       
/* Text("Main Color")
.font(.title2)
.fontWeight(.regular) */
      
                        Label("\(FDcolor.FDRGBCode1)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                                HStack(spacing: 35) {
                        
/*  Text("2")
.font(.subheadline)
.foregroundColor(.secondary) */
           
                        Label("\(FDcolor.FDRGBCode2)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                                HStack(spacing: 35) {
                    
/* Text("3")
.font(.subheadline)
.foregroundColor(.secondary) */
            
                        Label("\(FDcolor.FDRGBCode3)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                
                                HStack(spacing: 35) {
                    
/* Text("4")
.font(.subheadline)
.foregroundColor(.secondary) */
            
                        Label("\(FDcolor.FDRGBCode4)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                    HStack(spacing: 35) {
                    
/*  Text("5")
.font(.subheadline)
.foregroundColor(.secondary) */
                
                    Label("\(FDcolor.FDRGBCode5)", systemImage: "number.square.fill")
                        .font(.subheadline)
                        .foregroundColor(.primary)
                        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
            }
              
/*  Text(color.description)
.font(.footnote)
.foregroundColor(.secondary)
.padding() */
            
            Spacer()
            
//  Link(destination: color.url, label: {
//  StandartButton(title: "Watch Now")
            
            }
        }
    }



struct FDColorDetailView_Previews: PreviewProvider {
    static var previews: some View {
        FDColorDetailView(FDcolor: FDColorList.FDmainColor.first!)
    }
}

struct FDStandartButton: View {
    
    var title: String
    var body: some View {
        Text("Watch Now")
            .bold()
            .font(.title2)
            
// .frame(width: 280, height: 50)
// .background(Color(.systemRed))
            
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}
