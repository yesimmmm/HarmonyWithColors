//
//  FDColorListView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct FDColorListView: View {
    
    var FDcolors: [FDColor] = FDColorList.FDmainColor
    
    var body: some View {
        
        NavigationView {
            List(FDcolors, id: \.id) { FDColor in
                NavigationLink(destination: FDColorDetailView(FDcolor: FDColor), label: {
                    FDColorcell(FDcolor: FDColor)
                    })
            }
            
            .navigationTitle("First Date Colors")
      
        }
       
    }
   
}

struct FDColorcell: View {
    var FDcolor: FDColor
    
    var body: some View {
        
       
        HStack {
          
            Image(FDcolor.FDimageName)
                .resizable()
                .scaledToFit()
                .frame(height: 70)
                .cornerRadius(4)
                .padding(.vertical, 4)
            
            VStack(alignment: .leading, spacing: 5) {
             
                Text(FDcolor.FDtitle)
                    .fontWeight(.semibold)
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                    .minimumScaleFactor(0.5)
                Text("RGB Codes of all colors")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(FDcolor.FDRGBCode1)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
            }
        
        }
    }
}
struct FDColorListView_Previews: PreviewProvider {
    static var previews: some View {
        FDColorListView()
    }
}

