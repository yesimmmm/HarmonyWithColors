//
//  Color.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 1.12.2021.
//

import SwiftUI

struct MColor: Identifiable {
    let id = UUID()
    let mimageName: String
    let mtitle: String
    let mdescription: String
    let mRGBCode1: String
    let mRGBCode2: String
    let mRGBCode3: String
    let mRGBCode4: String
    let mRGBCode5: String
}

struct MColorList {
    static let mmainColor = [
        MColor(mimageName: "yellow",
        mtitle: "Yellow color and others",
        mdescription: ".",
        mRGBCode1: "#F2E307" ,
        mRGBCode2: "#069DBF" ,
        mRGBCode3: "#F2A007" ,
        mRGBCode4: "#F25D07" ,
        mRGBCode5: "#D93F07" ),
        
        MColor(mimageName: "green",
        mtitle: "Green color and others",
        mdescription: ".",
        mRGBCode1: "96D9B3" ,
        mRGBCode2: "D0F2DC" ,
        mRGBCode3: "72A603" ,
        mRGBCode4: "F2F2F0" ,
        mRGBCode5: "735443" ),
        
        MColor(mimageName: "purple",
        mtitle: "Purple color and others",
        mdescription: ".",
        mRGBCode1: "5549A6" ,
        mRGBCode2: "675ABF" ,
        mRGBCode3: "BF8069" ,
        mRGBCode4: "D9AC9C" ,
        mRGBCode5: "59332A" ),
        
        MColor(mimageName: "pink",
        mtitle: "Pink color and others",
        mdescription: ".",
        mRGBCode1: "F28095" ,
        mRGBCode2: "400112" ,
        mRGBCode3: "F2DCE4" ,
        mRGBCode4: "BF3B79" ,
        mRGBCode5: "F29979" ),
        
        MColor(mimageName: "orange",
        mtitle: "Orange color and others",
        mdescription: ".",
        mRGBCode1: "D96704" ,
        mRGBCode2: "F29F05" ,
        mRGBCode3: "F2B705" ,
        mRGBCode4: "736E30" ,
        mRGBCode5: "BF0426" ),
        
        MColor(mimageName: "blue",
        mtitle: "Blue color and others",
        mdescription: ".",
        mRGBCode1: "273D59" ,
        mRGBCode2: "4A6D8C" ,
        mRGBCode3: "C9DFF2" ,
        mRGBCode4: "80A7BF" ,
        mRGBCode5: "733E1F" ),
        
        MColor(mimageName: "beige",
        mtitle: "Beige color and others",
        mdescription: ".",
        mRGBCode1: "BFAC9B" ,
        mRGBCode2: "735B4D" ,
        mRGBCode3: "F2D0BD" ,
        mRGBCode4: "401F13" ,
        mRGBCode5: "BF826B" ),
        
        MColor(mimageName: "red",
        mtitle: "Red color and others",
        mdescription: ".",
        mRGBCode1: "F23535" ,
        mRGBCode2: "465902" ,
        mRGBCode3: "F2CB05" ,
        mRGBCode4: "F2B705" ,
        mRGBCode5: "A64F03" ),
    ]
}
