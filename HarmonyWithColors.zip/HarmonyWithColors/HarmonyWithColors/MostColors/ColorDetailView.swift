//
//  ColorDetailView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 1.12.2021.
//

import SwiftUI

struct ColorDetailView: View {
    var mcolor: MColor
    
    var body: some View {
        VStack(spacing:20) {
            Spacer()
            Text(mcolor.mtitle)
                .font(.title2)
                .fontWeight(.semibold)
                .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Image(mcolor.mimageName)
                .resizable()
                .scaledToFit()
                .frame(height: 150)
                .cornerRadius(12)
      
                    HStack(spacing: 35) {
//                    Text(mcolor.mimageName)
                        Text("( from left to right )")
                            .font(.footnote)
                            .foregroundColor(.secondary)
               
                    }
            
                VStack(spacing:20) {
                    HStack(spacing: 35) {
                 
// Text(color.imageName)
                       
/* Text("Main Color")
.font(.title2)
.fontWeight(.regular) */
      
                        Label("\(mcolor.mRGBCode1)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                                HStack(spacing: 35) {
                        
/*  Text("2")
.font(.subheadline)
.foregroundColor(.secondary) */
           
                        Label("\(mcolor.mRGBCode2)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                                HStack(spacing: 35) {
                    
/* Text("3")
.font(.subheadline)
.foregroundColor(.secondary) */
            
                        Label("\(mcolor.mRGBCode3)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                
                                HStack(spacing: 35) {
                    
/* Text("4")
.font(.subheadline)
.foregroundColor(.secondary) */
            
                        Label("\(mcolor.mRGBCode4)", systemImage: "number.square.fill")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                    HStack(spacing: 35) {
                    
/*  Text("5")
.font(.subheadline)
.foregroundColor(.secondary) */
                
                    Label("\(mcolor.mRGBCode5)", systemImage: "number.square.fill")
                        .font(.subheadline)
                        .foregroundColor(.primary)
                        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
            }
              
/*  Text(color.description)
.font(.footnote)
.foregroundColor(.secondary)
.padding() */
            
            Spacer()
            
//  Link(destination: color.url, label: {
//  StandartButton(title: "Watch Now")
            
            }
        }
    }



struct ColorDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ColorDetailView(mcolor: MColorList.mmainColor.first!)
    }
}

struct StandartButton: View {
    
    var mtitle: String
    var body: some View {
        Text("Watch Now")
            .bold()
            .font(.title2)
            
// .frame(width: 280, height: 50)
// .background(Color(.systemRed))
            
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}
