//
//  ContentView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 1.12.2021.
//

import SwiftUI

struct ColorListView: View {
    
    var mcolors: [MColor] = MColorList.mmainColor
    
    var body: some View {
        
        NavigationView {
            List(mcolors, id: \.id) { MColor in
                NavigationLink(destination: ColorDetailView(mcolor: MColor), label: {
                    MColorcell(mcolor: MColor)
                    })
            }
            
            .navigationTitle("Most Popular")
      
        }
       
    }
   
}

struct MColorcell: View {
    var mcolor: MColor
    
    var body: some View {
        
       
        HStack {
          
            Image(mcolor.mimageName)
                .resizable()
                .scaledToFit()
                .frame(height: 70)
                .cornerRadius(4)
                .padding(.vertical, 4)
            
            VStack(alignment: .leading, spacing: 5) {
             
                Text(mcolor.mtitle)
                    .fontWeight(.semibold)
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                    .minimumScaleFactor(0.5)
                Text("RGB Codes of all colors")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(mcolor.mRGBCode1)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
            }
        
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ColorListView()
    }
}

