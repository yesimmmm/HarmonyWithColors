//
//  CasualColorListView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 3.12.2021.
//

import SwiftUI

struct CasualColorListView: View {
    
    var ccolors: [CColor] = CColorList.cmainColor
    
    var body: some View {
        
        NavigationView {
            List(ccolors, id: \.id) { CColor in
                NavigationLink(destination: CasualColorDetailView(ccolor: CColor), label: {
                    CColorcell(ccolor: CColor)
                    })
            }
            
            .navigationTitle("Casual Colors")
      
        }
       
    }
   
}

struct CColorcell: View {
    var ccolor: CColor
    
    var body: some View {
        
       
        HStack {
          
            Image(ccolor.cimageName)
                .resizable()
                .scaledToFit()
                .frame(height: 70)
                .cornerRadius(4)
                .padding(.vertical, 4)
            
            VStack(alignment: .leading, spacing: 5) {
             
                Text(ccolor.ctitle)
                    .fontWeight(.semibold)
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                    .minimumScaleFactor(0.5)
                Text("RGB Codes of all colors")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(ccolor.cRGBCode1)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
            }
        
        }
    }
}
struct CasualColorListView_Previews: PreviewProvider {
    static var previews: some View {
        CasualColorListView()
    }
}

