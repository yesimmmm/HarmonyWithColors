//
//  casual.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct CColor: Identifiable {
    let id = UUID()
    let cimageName: String
    let ctitle: String
    let cdescription: String
    let cRGBCode1: String
    let cRGBCode2: String
    let cRGBCode3: String
    let cRGBCode4: String
    let cRGBCode5: String
}

struct CColorList {
    static let cmainColor = [
        CColor(cimageName: "graperoyal",
        ctitle: "Grape Royal color and others",
        cdescription: ".",
        cRGBCode1: "#734867" ,
        cRGBCode2: "#73624D" ,
        cRGBCode3: "#402E1E" ,
        cRGBCode4: "#A67356" ,
        cRGBCode5: "#A8A8A8" ),
        
        CColor(cimageName: "stone",
        ctitle: "Stone color and others",
        cdescription: ".",
        cRGBCode1: "#A69F97" ,
        cRGBCode2: "#BFB7AE" ,
        cRGBCode3: "#F2E4D8" ,
        cRGBCode4: "#736A62" ,
        cRGBCode5: "#594E47" ),
        
        CColor(cimageName: "sand",
        ctitle: "Sand color and others",
        cdescription: ".",
        cRGBCode1: "#BF988A" ,
        cRGBCode2: "#D9C1B8" ,
        cRGBCode3: "#592D23F" ,
        cRGBCode4: "#8C5A4F" ,
        cRGBCode5: "#EBECF2" ),
        
        ]
}
