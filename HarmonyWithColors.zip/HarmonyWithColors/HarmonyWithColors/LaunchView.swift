//
//  ContentView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 2.12.2021.
//

import SwiftUI


struct LaunchView: View {

    var body: some View {
       

         
        TabView {
            
     
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color(.systemTeal), Color(.systemPurple)]), startPoint: .top, endPoint: .bottom)
                
                    .edgesIgnoringSafeArea(.top)
                
                VStack(alignment: .center, spacing: 10) {
                   
                    
                   /* Image(systemName: "camera.filters")
                        .renderingMode(.original)
                        .font(.system(size: 90.0, weight: .thin))
                        .scaledToFit()
                        .frame(height: 140) */
                    
                   Image("logo12")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 120)
                     // .cornerRadius(12)
                        .padding(20)
                    
                    Text ("Harmony With Colors")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.leading)
                        .minimumScaleFactor(0.5)
                        .padding(20)
                    
                    Text("This app offers suggestions for color combinations you can use to look nice and match the style of your environment")
                        .font(/*@START_MENU_TOKEN@*/.subheadline/*@END_MENU_TOKEN@*/)
                        .fontWeight(.semibold)
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.5)
                        .padding(20)
                    
                }
            }
         
            .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            
                
                FormalColorListView ()
                    .tabItem {
                        Image(systemName: "highlighter")
                        Text("Formal")
                    }
                FDColorListView ()
                    .tabItem {
                        Image(systemName: "lasso.sparkles")
                        Text("FirstDate")
                        
                    }
            
                CasualColorListView ()
                    .tabItem {
                        Image(systemName: "music.quarternote.3")
                        Text("Casual")
                            
                    }
                ColorListView ()
                    .tabItem {
                        Image(systemName: "list.bullet")
                        Text("Most")
                    }
             
               /* AboutView ()
                    .tabItem {
                        Image(systemName: "questionmark")
                        Text("About")
                             
                    }
                BusinessColorListView ()
                .tabItem {
                    Image(systemName: "bag")
                    Text("Business")
                    
                } */
                .tabItem {
                    Image(systemName: "bag")
                    Text("List")
     
                }
            }
        }

struct LaunchView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchView()
    }
}
    
}

