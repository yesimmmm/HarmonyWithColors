//
//  BusinessColorListView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 3.12.2021.
//

import SwiftUI

struct BusinessColorListView: View {
    var body: some View {
        Text("BusinessColorListView")
    }
}

struct BusinessColorListView_Previews: PreviewProvider {
    static var previews: some View {
        BusinessColorListView()
    }
}
