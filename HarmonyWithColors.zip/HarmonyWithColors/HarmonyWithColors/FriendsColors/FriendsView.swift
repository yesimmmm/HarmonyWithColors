//
//  FriendsView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 3.12.2021.
//

import SwiftUI

struct FriendsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct FriendsView_Previews: PreviewProvider {
    static var previews: some View {
        FriendsView()
    }
}
