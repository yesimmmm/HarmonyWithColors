//
//  HarmonyWithColorsApp.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 1.12.2021.
//

import SwiftUI

@main
struct HarmonyWithColorsApp: App {
    var body: some Scene {
        WindowGroup {
            LaunchView()
        }
    }
}
