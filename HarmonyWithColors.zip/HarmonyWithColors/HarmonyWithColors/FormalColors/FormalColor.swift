//
//  FormalColor.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 3.12.2021.
//

import SwiftUI

struct FColor: Identifiable {
    let id = UUID()
    let fimageName: String
    let ftitle: String
    let fdescription: String
    let fRGBCode1: String
    let fRGBCode2: String
    let fRGBCode3: String
    let fRGBCode4: String
    let fRGBCode5: String
}

struct FColorList {
    static let fmainColor = [
        FColor(fimageName: "black",
        ftitle: "Yellow color and others",
        fdescription: ".",
        fRGBCode1: "#000000" ,
        fRGBCode2: "#1A1718" ,
        fRGBCode3: "#404040" ,
        fRGBCode4: "#808080" ,
        fRGBCode5: "#A8A8A8" ),
        
        FColor(fimageName: "darkblue",
        ftitle: "Dark Blue color and others",
        fdescription: ".",
        fRGBCode1: "#191726" ,
        fRGBCode2: "#1D3159" ,
        fRGBCode3: "#BFA584" ,
        fRGBCode4: "#F2F2F2" ,
        fRGBCode5: "#0D0D0D" ),
        
        FColor(fimageName: "gray2",
        ftitle: "Gray color and others",
        fdescription: ".",
        fRGBCode1: "#F0F1F2" ,
        fRGBCode2: "#5D6D73" ,
        fRGBCode3: "#B8BEBF" ,
        fRGBCode4: "#403425" ,
        fRGBCode5: "#0D0D0D" ),
        
        FColor(fimageName: "steel",
        ftitle: "Steel color and others",
        fdescription: ".",
        fRGBCode1: "#989CA6" ,
        fRGBCode2: "#3E4A59" ,
        fRGBCode3: "#BFBFBF" ,
        fRGBCode4: "#F2F2F0" ,
        fRGBCode5: "#0D0D0D" ),
        
        FColor(fimageName: "coffee",
        ftitle: "Coffee color and others",
        fdescription: ".",
        fRGBCode1: "#896335" ,
        fRGBCode2: "#E1AD6D" ,
        fRGBCode3: "#FAE9D5" ,
        fRGBCode4: "#5D5959" ,
        fRGBCode5: "#453624" ),
        
        FColor(fimageName: "mink",
        ftitle: "Mink color and others",
        fdescription: ".",
        fRGBCode1: "#4F473E" ,
        fRGBCode2: "#EFEDEA" ,
        fRGBCode3: "#393026" ,
        fRGBCode4: "#4B3E2E" ,
        fRGBCode5: "#131110" ),
        
        FColor(fimageName: "indigoblue",
        ftitle: "IndigoBlue color and others",
        fdescription: ".",
        fRGBCode1: "#151932" ,
        fRGBCode2: "#F8F8FB" ,
        fRGBCode3: "#1D2035" ,
        fRGBCode4: "#0D0E13" ,
        fRGBCode5: "#D66C8D" ),
    ]
}
