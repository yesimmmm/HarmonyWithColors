//
//  FormalColorListView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 3.12.2021.
//

import SwiftUI

struct FormalColorListView: View {
    var fcolors: [FColor] = FColorList.fmainColor
    var body: some View {
        
        VStack {
            NavigationView {
                List(fcolors, id: \.id) { FColor in
                    NavigationLink(destination: FormalColorDetailView(fcolor: FColor), label: {
                        FColorcell(fcolor: FColor)
                    })
                }
                .navigationTitle("Formal Colors")
            }
        }
       
     }
}
struct FColorcell: View {
    var fcolor: FColor
    var body: some View {
       
            HStack {
                Image(fcolor.fimageName)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 70)
                    .cornerRadius(4)
                    .padding(.vertical, 4)
                
                VStack(alignment: .leading, spacing: 5) {
                 
                    Text(fcolor.ftitle)
                        .fontWeight(.semibold)
                        .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                        .minimumScaleFactor(0.5)
                    Text("RGB Codes of all colors")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(fcolor.fRGBCode1)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                }
            }
        }
   }

struct FormalColorListView_Previews: PreviewProvider {
    static var previews: some View {
        FormalColorListView()
    }
}


