//
//  LaunchScreen.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct LaunchScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LaunchScreen_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreen()
    }
}
