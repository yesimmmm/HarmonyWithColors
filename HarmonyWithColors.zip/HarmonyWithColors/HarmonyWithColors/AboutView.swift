//
//  AboutView.swift
//  HarmonyWithColors
//
//  Created by Yeşim Göken on 4.12.2021.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        
        
       
        
        ZStack {
            
            VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 4) {
                
                Text("This app offers suggestions for color combinations you can use to look nice and match the style of your environment. These colors are not limited to your outfit;")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                  //  .padding(.leading, -94.0)
                    .padding(4)
                    .minimumScaleFactor(0.5)
                
                Text("Design a great look by considering all the elements such as shoes, hairpins, brooches, lipsticks, necklaces, belts, your skin color.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .padding(4)
                    .minimumScaleFactor(0.5)
                
                Text("When designing your look with colors, it is not enough to harmonize the colors with each other.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .padding(4)
                    .minimumScaleFactor(0.5)
                
                Text("Remember these three topics that inspired the three circles in our logo.the colors you use;must be compatible with each other,must comply with the rules of your environment,should reflect your style")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .padding(4)
                    .minimumScaleFactor(0.5)
                
          /*  Text("Before we go somewhere, we look at 3 things when choosing clothes;")
                .fontWeight(.light)
                .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                .minimumScaleFactor(0.5)
            Text("Does it suit my style? Do the colors match? Do the colors suit my destination?")
                .fontWeight(.light)
                .minimumScaleFactor(0.5)
            Text("As you know, while making these choices, we want to dress in colors suitable for the place we are going to and protect our own style.")
                .fontWeight(.light)
                .minimumScaleFactor(0.5)
            Text("This application offers you color matching suggestions suitable for the environment you are going to.")
                .fontWeight(.light)
                .minimumScaleFactor(0.5)
            Text("These 5 colors are not entirely composed of clothes. It includes other objects, such as your hair color, red lipstick, skin color. Thus, you can achieve complete visual compatibility.")
                .fontWeight(.light)
                .minimumScaleFactor(0.5)
            Text("We give the colors with RGB codes so that there is no tonal difference from the screens.")
                .fontWeight(.light)
                .minimumScaleFactor(0.5) */
            }
        }
    
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
}
